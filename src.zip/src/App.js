/** - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * SENAC - TADS - Programacao Web *
 * ADO #02 Trabalhando As Rotas e LINKS *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Nome : << Alexandre William Oliveira Coelho >> *
 * << Turma A - Matutino >> *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

import RouterApp from './Routes';

function App() {
  return (
    <RouterApp/>
  );
}
export default App;

