import './index.css';
import contacorrente from './contacorrente.webp';
function ContaCorrente(){
    return (
        <div>
            <h1 >Página da sua Conta Corrente</h1>
            <img src={contacorrente} width='500' height='250'></img><br/>
        </div>
    );
}
export default ContaCorrente;