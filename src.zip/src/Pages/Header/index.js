import { Link } from "react-router-dom";
import styles from './Header.module.css';
function Header(){
    return (
        <header>
            <div className="menu">
                <br/>
                <Link to='/'> || Home |</Link>
                <Link to='/meucadastro'>| Cadastro do cliente  |</Link>
                <Link to='/calcularFinancas'>| Calcular Finanças |</Link>
                <Link to='/contaCorrente'>| Conta Corrente |</Link>
                <Link to='/sobreNos'>| Sobre Nós || </Link>
            </div>
        </header>
    );
}
export default Header;