import welcome from './welcome.jpg';
import './index.css';
function Home(){
    return (
            <div>
                <h1>!-- Página Home --!</h1>
                <img src={welcome} width='500' height='250'></img><br/>
            </div>
    );
}
export default Home;