import './index.css';
import sobrenos from './sobrenos.png';
function SobreNos(){
    return (
        <div>
            <h1>Sobre nós</h1>
            <img src={sobrenos} width='500' height='250'></img><br/>
        </div>
    );
}
export default SobreNos;