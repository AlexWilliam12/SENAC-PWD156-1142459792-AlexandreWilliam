import './index.css';
import calcular from './calcular.webp';
function CalcuFinan(){
    return (
        <div>
            <h1>Página de Calcular Finanças</h1>
            <img src={calcular} width='500' height='250'></img><br/>
        </div>
    );
}
export default CalcuFinan;