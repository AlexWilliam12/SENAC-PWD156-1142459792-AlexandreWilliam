import analise from './analise.jpg';
import './index.css';
function Error(){
    return (
        <div id='ayuda'>
            <h1>Oops.. A página que procura não foi encontrada</h1><br/>
            <img src={analise} width='500' height='250'></img><br/>
        </div>
    );
}
export default Error;