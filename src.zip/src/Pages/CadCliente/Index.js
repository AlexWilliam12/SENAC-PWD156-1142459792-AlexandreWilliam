import './index.css';
import cadastro from './cadastro.jpg';
function Cadastro(){
    return (
            <div>
                <h1>Página de Cadastro</h1>
                <img src={cadastro} width='500' height='250'></img><br/>
            </div>
    );
}
export default Cadastro;