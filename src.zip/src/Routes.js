import { BrowserRouter,Routes,Route } from "react-router-dom";
import Home from './Pages/Home';
import CadCliente from './Pages/CadCliente/Index';
import CalcuFinan from "./Pages/CalcuFinan/Index";
import ContaCorrente from "./Pages/ContaCorrente/Index";
import SobreNos from "./Pages/sobNos";
import Error from './Pages/Error/Index';
import Header from './Pages/Header/index';
function RouterApp(){
    return (
        <BrowserRouter>
            <Header/>
            <Routes>
                <Route path="/" element={<Home/>}/>
                <Route path='/meucadastro' element={<CadCliente/>}/>
                <Route path='/calcularFinancas' element={<CalcuFinan/>}/>
                <Route path='/contaCorrente' element={<ContaCorrente/>}/>
                <Route path='/sobreNos' element={<SobreNos/>}/>
                <Route path='*' element={<Error/>}/>
            </Routes>
        </BrowserRouter>
    );
}
export default RouterApp;